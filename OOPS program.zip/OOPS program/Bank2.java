class BankAccount {
int accountNumber;
double balance;
BankAccount() {
accountNumber = 1001;
balance = 0.0;
}
BankAccount(int accNo, double initialBalance) {
accountNumber = accNo;
balance = initialBalance;
}
void deposit(double amount) {
balance = balance + amount;
}
void withdraw(double amount) {
if (amount <= balance) {
balance = balance - amount;
} 
else {
System.out.println("Insufficient balance!");
}
}
void displayAccount() {
System.out.println("Account Number: " + accountNumber);
System.out.println("Balance: ₹" + balance);
System.out.println();
}
}
public class Bank2{
public static void main(String[] args) {
BankAccount acc1 = new BankAccount();
acc1.displayAccount();
BankAccount acc2 = new BankAccount(2001, 5000);
acc2.deposit(1500);
acc2.withdraw(2000);
acc2.displayAccount();
}
}

class Studentt {
public String name;          
private int marks;           
protected String grade;     
int rollNumber;              
Student(String name, int rollNumber) {
this.name = name;
this.rollNumber = rollNumber;
}
public void setMarks(int marks) {
if (marks >= 0 && marks <= 100) {
this.marks = marks;
calculateGrade();         
} 
else {
System.out.println("Invalid marks! Enter between 0 and 100.");
}
}
private void calculateGrade() {
if (marks >= 90){
grade = "A";
}
else if (marks >= 75){
grade = "B";
}
else if (marks >= 50){
grade = "C";
}
else{
grade = "Fail";
}
}
public String getGrade() {
return grade;
}
protected void displayBasicInfo() {
System.out.println("Name: " + name);
System.out.println("Roll Number: " + rollNumber);
}
}
public class AccessModifier {
public static void main(String[] args) {
Student s = new Student("Rahul", 101);
s.setMarks(85); 
s.displayBasicInfo();
System.out.println("Grade: " + s.getGrade());
}
}

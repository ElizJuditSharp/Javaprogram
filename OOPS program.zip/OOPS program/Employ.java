class Employee {
static String companyName = "ABC Technologies";
static int employeeCount = 0;
int employeeId;
String employeeName;
Employee(String name) {
employeeName = name;
employeeCount++;        
employeeId = employeeCount;
}
static int getEmployeeCount() {
return employeeCount;
}
void displayEmployee() {
System.out.println("Employee ID: " + employeeId);
System.out.println("Employee Name: " + employeeName);
System.out.println("Company Name: " + companyName);
System.out.println();
}
}
public class Employ{
public static void main(String[] args) {
Employee e1 = new Employee("Rahul");
Employee e2 = new Employee("Anita");
Employee e3 = new Employee("Karthik");
e1.displayEmployee();
e2.displayEmployee();
e3.displayEmployee();
System.out.println("Total Employees: " +Employee.getEmployeeCount());
}
}

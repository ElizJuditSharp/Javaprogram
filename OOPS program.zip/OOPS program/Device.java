interface SmartDevice {
void turnOn();
void turnOff();
}
class Light implements SmartDevice {
public void turnOn() {
System.out.println("Smart Light is ON");
}
public void turnOff() {
System.out.println("Smart Light is OFF");
}
}
class Fan implements SmartDevice {
public void turnOn() {
System.out.println("Smart Fan is ON");
}
public void turnOff() {
System.out.println("Smart Fan is OFF");
}
}
public class Device{
public static void main(String[] args) {
SmartDevice device;
device = new Light();
device.turnOn();
device.turnOff();
device = new Fan();
device.turnOn();
device.turnOff();
}
}

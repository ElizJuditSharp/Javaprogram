class BankAccount{
private int accountNumber;
private double balance;
BankAccount(int accNo,double bal){
accountNumber=accNo;
balance=bal;
}
public void deposite(double amount){
if(amount>0){
balance+=amount;
}
}
public void withdraw(double amount){
if(amount <= balance){
balance-=amount;
}
else{
System.out.println("Insufficient Balance");
}
}
public double getBalance(){
return balance;
}
}
class Bank{
public static void main(String[] args){
BankAccount b1=new BankAccount(12345,1000);
b1.deposite(900);
b1.withdraw(300);
System.out.println("Balance:" +b1.getBalance());
}
}
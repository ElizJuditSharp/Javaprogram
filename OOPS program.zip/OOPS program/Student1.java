class Student{
String name;
int roll;
int marks;
void setDetails(String n , int r , int m){
name=n;
roll=r;
marks=m;
}
void displayDetails(){
System.out.println("Name:" +name);
System.out.println("roll no:" +roll);
System.out.println("mark:" +marks);
}
boolean isPassed(){                                                                
if(marks>=40)
return true;
else 
return false;
}
}
class Student1{
public static void main(String[] args){
Student s1=new Student();
Student s2=new Student();
s1.setDetails("Ramya",2310315,70);
s1.displayDetails();
System.out.println("passed:" +s1.isPassed());
s2.setDetails("Priya",2310319,34);
s2.displayDetails();
System.out.println("passed:" +s2.isPassed());
}
}
abstract class Shape {
abstract void calculateArea();
void displayShape() {
System.out.println("This is a Shape");
}
}
class Circle extends Shape {
double radius = 5;
void calculateArea() {
double area = 3.14 * radius * radius;
System.out.println("Area of Circle: " + area);
}
}
class Rectangle extends Shape {
int length = 4;
int breadth = 6;
void calculateArea() {
int area = length * breadth;
System.out.println("Area of Rectangle: " + area);
}
}
public class Abstraction{
public static void main(String[] args) {
Shape s;
s = new Circle();
s.displayShape();
s.calculateArea();
s = new Rectangle();
s.displayShape();
s.calculateArea();
}
}
